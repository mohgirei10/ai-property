import { Image, Pressable, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import { Property } from "../lib/data";
import { useApp } from "../lib/store";

export function Heart({ id }: { id: string }) {
  const { favs, toggleFav } = useApp();
  const on = favs.includes(id);
  return <Pressable hitSlop={10} accessibilityRole="button" accessibilityLabel={on ? "Remove from saved properties" : "Save property"} accessibilityState={{ selected: on }} onPress={() => { void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined); toggleFav(id); }} className="w-9 h-9 rounded-full bg-[#111722]/90 border border-white/15 items-center justify-center">
    <Ionicons name={on ? "heart" : "heart-outline"} size={18} color={on ? "#F08B9A" : "#FFFFFF"} />
  </Pressable>;
}

export function PropertyCard({ p }: { p: Property }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={`View ${p.title}, ${p.price}`} onPress={() => router.push(`/property/${p.id}`)} className="flex-row bg-[#151D29] border border-[#2B3544] rounded-3xl p-3">
    <Image source={{ uri: p.image }} className="w-28 h-28 rounded-2xl bg-[#202B3A]" accessibilityLabel={`${p.title} property photograph`} />
    <View className="flex-1 ml-3 justify-between">
      <View className="flex-row items-start"><Text className="flex-1 text-white font-semibold text-sm pr-2" numberOfLines={2}>{p.title}</Text><Heart id={p.id}/></View>
      <View className="flex-row items-center"><Ionicons name="location-outline" size={12} color="#929BAA"/><Text className="text-[#929BAA] text-[11px] ml-1" numberOfLines={1}>{p.location}</Text></View>
      <View className="flex-row items-center justify-between"><Text className="text-[#E8CB91] text-sm font-bold">{p.price}</Text><Text className="text-[#A7B0BE] text-[10px]">{p.beds} bd · {p.baths} ba · {p.area} m²</Text></View>
    </View>
  </Pressable>;
}
