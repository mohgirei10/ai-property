import { FlatList, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { PropertyCard } from "../../components/PropertyCard";
import { properties } from "../../lib/data";
import { useApp } from "../../lib/store";

export default function Favorites() {
  const { favs } = useApp();
  const items = properties.filter((p) => favs.includes(p.id));
  return <SafeAreaView edges={["top"]} className="flex-1 bg-[#080B12]">
    <View className="px-5 pt-4 pb-4"><Text className="text-[#929BAA] text-xs tracking-widest">YOUR SHORTLIST</Text><Text className="text-white text-3xl font-bold mt-1">Saved properties</Text><Text className="text-[#929BAA] text-sm mt-2">{items.length} {items.length === 1 ? "property" : "properties"} saved for later.</Text></View>
    <FlatList data={items} keyExtractor={(p) => p.id} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 120, gap: 12, flexGrow: 1 }} renderItem={({ item }) => <PropertyCard p={item}/>} ListEmptyComponent={<View className="items-center justify-center flex-1 px-10"><View className="w-20 h-20 rounded-full bg-[#151D29] items-center justify-center border border-[#303A49]"><Ionicons name="heart-outline" size={34} color="#D6B779"/></View><Text className="text-white font-semibold text-lg mt-4">Your shortlist starts here</Text><Text className="text-[#929BAA] text-center text-sm mt-2 leading-5">Tap the heart on a property to save it and compare your favourites later.</Text></View>}/>
  </SafeAreaView>;
}
