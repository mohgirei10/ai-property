import { Pressable, ScrollView, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { router } from "expo-router";
import { PropertyCard } from "../../components/PropertyCard";
import { properties } from "../../lib/data";

export default function DiscoverMapTab() {
  return <SafeAreaView edges={["top"]} className="flex-1 bg-[#080B12]"><ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 120 }}>
    <Text className="text-[#929BAA] text-xs tracking-widest">LOCATION DISCOVERY</Text><Text className="text-white text-3xl font-bold mt-1">Explore the map</Text><Text className="text-[#929BAA] text-sm mt-2">See available properties around a location.</Text>
    <Pressable onPress={() => router.push("/map")} className="mt-5 h-56 rounded-3xl border border-[#303A49] bg-[#151D29] overflow-hidden p-5 justify-between">
      <View className="flex-row justify-between items-center"><View className="bg-[#202B3A] rounded-full px-3 py-2 flex-row items-center gap-2"><Ionicons name="location" color="#D6B779"/><Text className="text-white text-xs">Map preview</Text></View><Ionicons name="expand-outline" color="#D6B779" size={20}/></View>
      <View className="items-center"><View className="w-16 h-16 rounded-full border border-[#D6B779]/40 bg-[#D6B779]/10 items-center justify-center"><Ionicons name="map" size={30} color="#D6B779"/></View><Text className="text-white font-semibold mt-3">Open interactive map</Text><Text className="text-[#929BAA] text-xs mt-1">Browse nearby listings and location filters</Text></View>
      <Text className="text-[#D6B779] text-xs font-semibold">OPEN MAP  ↗</Text>
    </Pressable>
    <View className="flex-row justify-between items-center mt-7 mb-3"><Text className="text-white text-lg font-bold">Properties to explore</Text><Text className="text-[#929BAA] text-xs">{properties.length} listings</Text></View>
    <View className="gap-3">{properties.slice(0, 4).map((p) => <PropertyCard key={p.id} p={p}/>)}</View>
    <Text className="text-[#778292] text-xs mt-4 leading-5">Map pins and listing coordinates are demo data in this build. Live geospatial search requires a connected listings service and verified coordinates.</Text>
  </ScrollView></SafeAreaView>;
}
