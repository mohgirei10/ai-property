import { useMemo, useState } from "react";
import { ImageBackground, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { PropertyCard } from "../../components/PropertyCard";
import { properties } from "../../lib/data";
import { useApp } from "../../lib/store";

const gold = "#D6B779";
const categories = ["All", "House", "Apartment", "Villa", "Land"];

export default function Home() {
  const { user } = useApp();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const featured = properties[2] ?? properties[0];
  const recent = useMemo(() => properties.filter((p) => category === "All" || p.title.toLowerCase().includes(category.toLowerCase())), [category]);
  const search = () => router.push({ pathname: "/(tabs)/explore", params: { q: query } });

  return <SafeAreaView edges={["top"]} className="flex-1 bg-[#080B12]">
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 110 }}>
      <View className="px-5 pt-3">
        <View className="flex-row items-center justify-between">
          <View><Text className="text-[#929BAA] text-xs tracking-widest">PROPERTY FINDER</Text><Text className="text-white text-2xl font-bold mt-1">Discover your place.</Text><Text className="text-[#929BAA] text-sm mt-1">Good to see you, {user?.name?.split(" ")[0] || "there"}.</Text></View>
          <Pressable onPress={() => router.push("/(tabs)/profile")} className="w-11 h-11 rounded-full border border-[#303A49] bg-[#151D29] items-center justify-center"><Ionicons name="person-outline" color={gold} size={20} /></Pressable>
        </View>
        <Pressable onPress={() => router.push("/(tabs)/explore")} className="mt-5 flex-row items-center rounded-2xl bg-[#141C28] border border-[#293444] px-4 py-4">
          <Ionicons name="search" size={19} color={gold} /><Text className="text-[#8F99A8] ml-3 flex-1">City, neighbourhood or property...</Text><View className="bg-[#D6B779] rounded-xl p-2"><Ionicons name="options-outline" color="#111722" size={17} /></View>
        </Pressable>
        <View className="flex-row justify-between items-center mt-7 mb-3"><Text className="text-white text-lg font-bold">Featured property</Text><Text className="text-[#D6B779] text-xs">HANDPICKED</Text></View>
        <Pressable onPress={() => router.push(`/property/${featured.id}`)} className="h-64 rounded-3xl overflow-hidden border border-[#303A49]">
          <ImageBackground source={{ uri: featured.image }} resizeMode="cover" className="flex-1 justify-end"><LinearGradient colors={["transparent", "rgba(5,8,13,0.92)"]} style={{ position: "absolute", left: 0, right: 0, top: 0, bottom: 0 }} />
            <View className="p-5"><View className="self-start rounded-full bg-[#D6B779] px-3 py-1 mb-3"><Text className="text-[#111722] text-[10px] font-bold tracking-widest">FEATURED</Text></View><Text className="text-white text-2xl font-bold">{featured.title}</Text><Text className="text-white/75 text-xs mt-1">{featured.location}</Text><View className="flex-row items-center justify-between mt-4"><Text className="text-[#E8CB91] text-xl font-bold">{featured.price}</Text><View className="flex-row gap-3"><Text className="text-white/80 text-xs">{featured.beds} beds</Text><Text className="text-white/80 text-xs">{featured.baths} baths</Text><Text className="text-white/80 text-xs">{featured.area} m²</Text></View></View></View>
          </ImageBackground>
        </Pressable>
        <View className="flex-row justify-between items-center mt-7 mb-3"><Text className="text-white text-lg font-bold">Explore by type</Text><Text className="text-[#8F99A8] text-xs">Find your fit</Text></View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 9 }}>
          {categories.map((c) => <Pressable key={c} onPress={() => setCategory(c)} className={`px-4 py-2.5 rounded-full border ${category === c ? "bg-[#D6B779] border-[#D6B779]" : "bg-[#141C28] border-[#293444]"}`}><Text className={`text-xs font-semibold ${category === c ? "text-[#111722]" : "text-[#B5BDCA]"}`}>{c}</Text></Pressable>)}
        </ScrollView>
        <View className="flex-row justify-between items-center mt-7 mb-3"><Text className="text-white text-lg font-bold">Recently added</Text><Pressable onPress={() => router.push("/(tabs)/explore")}><Text className="text-[#D6B779] text-xs font-semibold">View all  ↗</Text></Pressable></View>
        <View className="gap-3">{recent.slice(0, 4).map((p) => <PropertyCard key={p.id} p={p} />)}</View>
        <View className="mt-6 rounded-2xl bg-[#151D29] border border-[#303A49] p-4 flex-row items-center"><View className="w-10 h-10 rounded-xl bg-[#D6B779]/15 items-center justify-center"><Ionicons name="business-outline" color={gold} size={20} /></View><View className="flex-1 ml-3"><Text className="text-white font-semibold">Have a property to list?</Text><Text className="text-[#929BAA] text-xs mt-1">Reach buyers and renters around the world.</Text></View><Ionicons name="arrow-forward" color={gold} size={18} /></View>
      </View>
    </ScrollView>
  </SafeAreaView>;
}
