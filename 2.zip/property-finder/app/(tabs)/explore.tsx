import { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { useLocalSearchParams, router } from "expo-router";
import { PropertyCard } from "../../components/PropertyCard";
import { properties } from "../../lib/data";

export default function Explore() {
  const params = useLocalSearchParams<{ q?: string }>();
  const [query, setQuery] = useState(params.q ?? "");
  const [beds, setBeds] = useState(0);
  const [kind, setKind] = useState("All");
  const results = useMemo(() => properties.filter((p) => {
    const q = query.toLowerCase();
    return (!q || `${p.title} ${p.location}`.toLowerCase().includes(q)) && (!beds || p.beds >= beds) && (kind === "All" || p.title.toLowerCase().includes(kind.toLowerCase()));
  }), [query, beds, kind]);
  return <SafeAreaView edges={["top"]} className="flex-1 bg-[#080B12]"><ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 120 }} keyboardShouldPersistTaps="handled">
    <Text className="text-[#929BAA] text-xs tracking-widest">DISCOVER</Text><Text className="text-white text-3xl font-bold mt-1">Explore properties</Text><Text className="text-[#929BAA] text-sm mt-2">Search homes, spaces and opportunities worldwide.</Text>
    <View className="mt-5 flex-row items-center bg-[#141C28] border border-[#293444] rounded-2xl px-4 py-3"><Ionicons name="search" color="#D6B779" size={19}/><TextInput value={query} onChangeText={setQuery} placeholder="Try a city or neighbourhood" placeholderTextColor="#7D8796" className="flex-1 text-white ml-3 py-1" returnKeyType="search" /></View>
    <View className="flex-row items-center justify-between mt-5 mb-3"><Text className="text-white font-semibold">Property type</Text><Pressable onPress={() => { setKind("All"); setBeds(0); setQuery(""); }}><Text className="text-[#D6B779] text-xs">Reset</Text></Pressable></View>
    <View className="flex-row flex-wrap gap-2">{["All", "House", "Apartment", "Land"].map((k) => <Pressable key={k} onPress={() => setKind(k)} className={`px-4 py-2.5 rounded-full border ${kind === k ? "bg-[#D6B779] border-[#D6B779]" : "bg-[#141C28] border-[#293444]"}`}><Text className={`text-xs font-semibold ${kind === k ? "text-[#111722]" : "text-[#B5BDCA]"}`}>{k}</Text></Pressable>)}</View>
    <Text className="text-white font-semibold mt-5 mb-3">Bedrooms</Text><View className="flex-row gap-2">{[0,1,2,3,4,5].map((n) => <Pressable key={n} onPress={() => setBeds(n)} className={`w-10 h-10 rounded-xl items-center justify-center border ${beds === n ? "bg-[#D6B779] border-[#D6B779]" : "bg-[#141C28] border-[#293444]"}`}><Text className={`text-xs font-semibold ${beds === n ? "text-[#111722]" : "text-white"}`}>{n || "Any"}</Text></Pressable>)}</View>
    <View className="flex-row justify-between items-center mt-7 mb-3"><Text className="text-white text-lg font-bold">Matching properties</Text><Text className="text-[#929BAA] text-xs">{results.length} results</Text></View>
    {results.length ? <View className="gap-3">{results.map((p) => <PropertyCard key={p.id} p={p}/>)}</View> : <View className="rounded-3xl border border-[#293444] bg-[#141C28] p-7 items-center mt-3"><Ionicons name="search-outline" size={32} color="#D6B779"/><Text className="text-white font-semibold mt-3">No properties found</Text><Text className="text-[#929BAA] text-xs text-center mt-1">Try a broader location or remove a filter.</Text></View>}
    <Pressable onPress={() => router.push("/map")} className="mt-5 rounded-2xl bg-[#D6B779] py-4 flex-row justify-center items-center gap-2"><Ionicons name="map-outline" color="#111722" size={17}/><Text className="text-[#111722] font-bold">Explore on map</Text></Pressable>
  </ScrollView></SafeAreaView>;
}
