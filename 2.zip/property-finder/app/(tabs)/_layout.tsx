import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";

const icon = (name: keyof typeof Ionicons.glyphMap) => ({ color, focused }: { color: string; focused: boolean }) => (
  <Ionicons name={name} size={21} color={color} />
);

export default function TabsLayout() {
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarShowLabel: true,
      tabBarActiveTintColor: "#D6B779",
      tabBarInactiveTintColor: "#7D8491",
      tabBarLabelStyle: { fontSize: 10, fontWeight: "600", marginBottom: 5 },
      tabBarStyle: { position: "absolute", left: 14, right: 14, bottom: 12, height: 66, borderRadius: 22, backgroundColor: "#111722", borderTopWidth: 1, borderColor: "#283140", paddingTop: 8, paddingBottom: 5, elevation: 12 },
      tabBarItemStyle: { height: 54 },
    }}>
      <Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: icon("home-outline") }} />
      <Tabs.Screen name="explore" options={{ title: "Explore", tabBarIcon: icon("search-outline") }} />
      <Tabs.Screen name="discover-map" options={{ title: "Map", tabBarIcon: icon("map-outline") }} />
      <Tabs.Screen name="favorites" options={{ title: "Saved", tabBarIcon: icon("heart-outline") }} />
      <Tabs.Screen name="profile" options={{ title: "Profile", tabBarIcon: icon("person-outline") }} />
    </Tabs>
  );
}
