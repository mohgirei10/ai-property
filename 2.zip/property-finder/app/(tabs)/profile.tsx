import { Pressable, ScrollView, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../../lib/store";

const gold = "#D6B779";
export default function Profile() {
  const { user, favs, signOut } = useApp();
  const rows = [{ icon: "heart-outline" as const, title: "Saved properties", sub: `${favs.length} saved` }, { icon: "calendar-outline" as const, title: "My inspections", sub: "Manage property visits" }, { icon: "home-outline" as const, title: "My listings", sub: "Owner and agent tools" }, { icon: "shield-checkmark-outline" as const, title: "Verification", sub: "Build trust with buyers" }, { icon: "settings-outline" as const, title: "Preferences", sub: "Language, currency and privacy" }, { icon: "help-circle-outline" as const, title: "Help and support", sub: "Get assistance" }];
  return <SafeAreaView edges={["top"]} className="flex-1 bg-[#080B12]"><ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 120 }}>
    <Text className="text-[#929BAA] text-xs tracking-widest">YOUR ACCOUNT</Text><Text className="text-white text-3xl font-bold mt-1">Profile</Text>
    <View className="mt-5 rounded-3xl bg-[#151D29] border border-[#303A49] p-5 flex-row items-center"><View className="w-14 h-14 rounded-full bg-[#D6B779]/15 border border-[#D6B779]/40 items-center justify-center"><Text className="text-[#D6B779] text-xl font-bold">{user?.name?.[0]?.toUpperCase() || "G"}</Text></View><View className="ml-4 flex-1"><Text className="text-white font-bold text-base">{user?.name || "Guest account"}</Text><Text className="text-[#929BAA] text-xs mt-1">{user?.email || "Sign in to sync your activity"}</Text></View><Ionicons name="chevron-forward" color="#929BAA" size={18}/></View>
    <View className="flex-row gap-3 mt-4"><View className="flex-1 rounded-2xl bg-[#151D29] border border-[#303A49] p-4"><Text className="text-[#929BAA] text-xs">Saved</Text><Text className="text-white text-2xl font-bold mt-1">{favs.length}</Text></View><View className="flex-1 rounded-2xl bg-[#151D29] border border-[#303A49] p-4"><Text className="text-[#929BAA] text-xs">Account type</Text><Text className="text-white text-base font-bold mt-2">{user?.email ? "Member" : "Guest"}</Text></View></View>
    <Text className="text-white font-bold text-lg mt-7 mb-3">Account & services</Text>
    <View className="rounded-2xl border border-[#303A49] bg-[#151D29] overflow-hidden">{rows.map((r, i) => <Pressable key={r.title} onPress={() => {}} className={`flex-row items-center p-4 ${i ? "border-t border-[#283140]" : ""}`}><View className="w-10 h-10 rounded-xl bg-[#D6B779]/10 items-center justify-center"><Ionicons name={r.icon} color={gold} size={19}/></View><View className="flex-1 ml-3"><Text className="text-white text-sm font-semibold">{r.title}</Text><Text className="text-[#929BAA] text-xs mt-1">{r.sub}</Text></View><Ionicons name="chevron-forward" color="#7D8796" size={17}/></Pressable>)}</View>
    <Pressable onPress={signOut} className="mt-5 rounded-full border border-[#49343A] bg-[#21171C] py-4 items-center"><Text className="text-[#F0A7A7] font-semibold">Sign out</Text></Pressable>
    <Text className="text-[#667181] text-center text-[10px] mt-5">PROPERTY FINDER · GLOBAL PROPERTY MARKETPLACE</Text>
  </ScrollView></SafeAreaView>;
}
