export type Filters = { type?: string; location?: string; minPrice?: number; maxPrice?: number; beds?: number };

const API = process.env.EXPO_PUBLIC_AI_SEARCH_URL;

/** AI requests are sent only to your own backend. Never expose a provider secret in an Expo client bundle. */
export async function aiSearch(text: string): Promise<Filters> {
  if (API) {
    try {
      const response = await fetch(API, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query: text }),
      });
      if (!response.ok) throw new Error(`AI search failed (${response.status})`);
      const data = await response.json();
      return Object.fromEntries(Object.entries(data as Filters).filter(([, value]) => value != null));
    } catch {
      // Keep search usable if the optional backend is unavailable.
    }
  }
  return heuristic(text);
}

// Offline fallback so search still works without an API key.
function heuristic(t: string): Filters {
  const f: Filters = {};
  const amt = (m: RegExpMatchArray) => parseFloat(m[1].replace(/,/g, "")) * (m[2] ? (m[2].toLowerCase() === "k" ? 1e3 : 1e6) : 1);
  const type = t.match(/house|apartment|land/i)?.[0];
  if (type) f.type = type[0].toUpperCase() + type.slice(1).toLowerCase();
  const beds = t.match(/(\d+)\s*(?:bed|br)/i);
  if (beds) f.beds = +beds[1];
  const max = t.match(/(?:under|below|max|<)\s*\$?([\d,.]+)\s*(k|m)?/i);
  if (max) f.maxPrice = amt(max);
  const min = t.match(/(?:over|above|min|>)\s*\$?([\d,.]+)\s*(k|m)?/i);
  if (min) f.minPrice = amt(min);
  const loc = t.match(/\b(?:in|near|at)\s+([A-Z][a-z]+(?: [A-Z][a-z]+)*)/);
  if (loc) f.location = loc[1];
  return f;
}
