# AI Property Finder

Expo Router property discovery app with native iOS/Android maps and a browser-safe map experience.

## Requirements

- Node.js LTS
- npm
- GitHub Codespaces or a local development environment

## Install

```bash
npm run setup
```

The setup script installs dependencies compatible with the Expo SDK declared in `package.json`, including Expo Router, NativeWind, native maps, and Expo Web dependencies.

## Run in iPhone Safari / Chrome through GitHub Codespaces

```bash
npm run web
```

In Codespaces, open the **Ports** panel, make sure port **8081** is forwarded, and open the forwarded HTTPS URL on your iPhone. Set port visibility to **Public** only if you need to share the preview with someone else; otherwise keep it private.

If the browser shows a stale bundle, run:

```bash
npm run web:clear
```

## Run on a real iPhone with Expo Go

```bash
npm start
```

Scan the QR code with the iPhone Camera app and open it in Expo Go. Native maps are used on iOS/Android; the web build uses `app/map.web.tsx` and does not import `react-native-maps`.

## Build

```bash
npx eas-cli build --platform android
npx eas-cli build --platform ios
```

An iOS development or production build requires the appropriate Apple Developer account/signing setup.

## Environment variables

Copy `.env.example` to `.env` if you need the optional keys. `EXPO_PUBLIC_*` variables are bundled into client apps and must never contain private production secrets. The AI search has an offline heuristic fallback when no key is supplied. For production, proxy AI requests through a secured backend.

## Platform-specific map files

- `app/map.tsx`: native iOS and Android implementation using `react-native-maps`.
- `app/map.web.tsx`: browser-compatible property search and listing view with an OpenStreetMap link.
