import { Image, Pressable, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import { Property } from "../lib/data";
import { useApp } from "../lib/store";

export function Heart({ id }: { id: string }) {
  const { favs, toggleFav } = useApp();
  const on = favs.includes(id);
  return (
    <Pressable
      hitSlop={10}
      onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); toggleFav(id); }}
      className="w-9 h-9 rounded-full bg-gray-100 items-center justify-center"
    >
      <Ionicons name={on ? "heart" : "heart-outline"} size={18} color={on ? "#E11D48" : "#0B0B0C"} />
    </Pressable>
  );
}

export function PropertyCard({ p }: { p: Property }) {
  return (
    <Pressable onPress={() => router.push(`/property/${p.id}`)} className="flex-row bg-white rounded-3xl p-3 shadow-lg">
      <Image source={{ uri: p.image }} className="w-28 h-28 rounded-2xl" />
      <View className="flex-1 ml-3 justify-between">
        <View className="flex-row items-start">
          <Text className="flex-1 font-semibold text-sm pr-2" numberOfLines={2}>{p.title}</Text>
          <Heart id={p.id} />
        </View>
        <Text className="text-gray-400 text-[11px]" numberOfLines={1}>{p.location}</Text>
        <View className="flex-row items-center justify-between">
          <View className="bg-brand rounded-full px-2.5 py-1"><Text className="text-pine text-xs font-bold">{p.price}</Text></View>
          <Text className="text-gray-500 text-[11px]">{p.beds} bd · {p.baths} ba · {p.area} m²</Text>
        </View>
      </View>
    </Pressable>
  );
}
