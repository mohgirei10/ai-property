const G = process.env.EXPO_PUBLIC_GOOGLE_MAPS_KEY;
export type Place = { name: string; lat: number; lng: number };

export async function geocode(q: string): Promise<Place | null> {
  try {
    if (G) {
      const r = await (await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(q)}&key=${G}`)).json();
      const x = r.results?.[0];
      return x ? { name: x.formatted_address, lat: x.geometry.location.lat, lng: x.geometry.location.lng } : null;
    }
    const r = await (
      await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(q)}`, { headers: { "User-Agent": "ai-property-finder" } })
    ).json();
    return r[0] ? { name: r[0].display_name.split(",").slice(0, 2).join(","), lat: +r[0].lat, lng: +r[0].lon } : null;
  } catch {
    return null;
  }
}
