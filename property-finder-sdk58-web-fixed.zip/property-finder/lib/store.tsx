import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, ReactNode, useContext, useEffect, useState } from "react";

type User = { name: string; email: string };
type State = { ready: boolean; seen: boolean; user: User | null; favs: string[] };
type Ctx = State & { finishOnboarding(): void; signIn(u: User): void; signOut(): void; toggleFav(id: string): void };

const init: State = { ready: false, seen: false, user: null, favs: [] };
const C = createContext<Ctx>(null!);
export const useApp = () => useContext(C);

export function AppProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<State>(init);

  useEffect(() => {
    AsyncStorage.getItem("app").then((v) => setS({ ...init, ...(v ? JSON.parse(v) : {}), ready: true }));
  }, []);

  const save = (p: Partial<State>) =>
    setS((o) => {
      const n = { ...o, ...p };
      AsyncStorage.setItem("app", JSON.stringify({ seen: n.seen, user: n.user, favs: n.favs }));
      return n;
    });

  return (
    <C.Provider
      value={{
        ...s,
        finishOnboarding: () => save({ seen: true }),
        signIn: (user) => save({ user }),
        signOut: () => save({ user: null }),
        toggleFav: (id) => save({ favs: s.favs.includes(id) ? s.favs.filter((x) => x !== id) : [...s.favs, id] }),
      }}
    >
      {children}
    </C.Provider>
  );
}
