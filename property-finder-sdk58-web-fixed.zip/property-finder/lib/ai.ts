export type Filters = { type?: string; location?: string; minPrice?: number; maxPrice?: number; beds?: number };

const KEY = process.env.EXPO_PUBLIC_ANTHROPIC_KEY;
const SYSTEM =
  'Extract property search filters from the request. Reply with ONLY JSON: {"type":"House"|"Apartment"|"Land"|null,"location":string|null,"minPrice":number|null,"maxPrice":number|null,"beds":number|null}. Prices are plain USD numbers.';

export async function aiSearch(text: string): Promise<Filters> {
  if (KEY) {
    try {
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 200, system: SYSTEM, messages: [{ role: "user", content: text }] }),
      });
      const j = await r.json();
      const raw = JSON.parse(j.content[0].text.replace(/```json|```/g, "").trim());
      return Object.fromEntries(Object.entries(raw).filter(([, v]) => v != null));
    } catch {}
  }
  return heuristic(text);
}

// Offline fallback so search still works without an API key.
function heuristic(t: string): Filters {
  const f: Filters = {};
  const amt = (m: RegExpMatchArray) => parseFloat(m[1].replace(/,/g, "")) * (m[2] ? (m[2].toLowerCase() === "k" ? 1e3 : 1e6) : 1);
  const type = t.match(/house|apartment|land/i)?.[0];
  if (type) f.type = type[0].toUpperCase() + type.slice(1).toLowerCase();
  const beds = t.match(/(\d+)\s*(?:bed|br)/i);
  if (beds) f.beds = +beds[1];
  const max = t.match(/(?:under|below|max|<)\s*\$?([\d,.]+)\s*(k|m)?/i);
  if (max) f.maxPrice = amt(max);
  const min = t.match(/(?:over|above|min|>)\s*\$?([\d,.]+)\s*(k|m)?/i);
  if (min) f.minPrice = amt(min);
  const loc = t.match(/\b(?:in|near|at)\s+([A-Z][a-z]+(?: [A-Z][a-z]+)*)/);
  if (loc) f.location = loc[1];
  return f;
}
