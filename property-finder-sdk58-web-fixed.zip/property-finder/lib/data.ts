export type Property = {
  id: string; title: string; location: string; price: string; image: string;
  beds: number; baths: number; area: number; url: string; lat: number; lng: number;
};

const img = (id: string) => `https://images.unsplash.com/${id}?w=900&q=80`;
const loc = "Gumpang, Kartasura, Surakarta";

export const properties: Property[] = [
  { id: "1", title: "House for sale at Dafros Residence", location: loc, price: "$75,000", image: img("photo-1613490493576-7fde63acd811"), beds: 3, baths: 2, area: 240, url: "https://www.rumah.com/rumah-dijual/dafros", lat: -7.5545, lng: 110.743 },
  { id: "2", title: "House for sale at Griya Asri", location: loc, price: "$62,000", image: img("photo-1600596542815-ffad4c1539a9"), beds: 2, baths: 1, area: 180, url: "https://www.rumah.com/rumah-dijual/griya-asri", lat: -7.5575, lng: 110.7475 },
  { id: "3", title: "House for sale at Taman Sari", location: loc, price: "$98,000", image: img("photo-1600585154340-be6161a56a0c"), beds: 4, baths: 3, area: 320, url: "https://www.rumah.com/rumah-dijual/taman-sari", lat: -7.5515, lng: 110.7455 },
  { id: "4", title: "House for sale at Pesona Indah", location: loc, price: "$54,500", image: img("photo-1564013799919-ab600027ffc6"), beds: 2, baths: 2, area: 150, url: "https://www.rumah.com/rumah-dijual/pesona-indah", lat: -7.5595, lng: 110.7415 },
  { id: "5", title: "House for sale at Bukit Permai", location: loc, price: "$120,000", image: img("photo-1512917774080-9991f1c4c750"), beds: 5, baths: 4, area: 410, url: "https://www.rumah.com/rumah-dijual/bukit-permai", lat: -7.5525, lng: 110.7395 },
  { id: "6", title: "House for sale at Cluster Melati", location: loc, price: "$68,000", image: img("photo-1568605114967-8130f3a36994"), beds: 3, baths: 2, area: 210, url: "https://www.rumah.com/rumah-dijual/cluster-melati", lat: -7.5605, lng: 110.7445 },
];

export const BASE = { lat: -7.5555, lng: 110.743 };
export const priceOf = (p: Property) => Number(p.price.replace(/\D/g, ""));
