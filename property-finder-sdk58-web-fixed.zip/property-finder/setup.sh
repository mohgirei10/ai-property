#!/usr/bin/env bash
set -euo pipefail

# Install the Expo SDK-matched native and web dependencies.
npm install --legacy-peer-deps
npx expo install expo-router react react-native react-native-screens react-native-safe-area-context \
  react-native-reanimated react-native-worklets react-native-maps expo-font expo-haptics \
  expo-linear-gradient expo-status-bar expo-linking expo-constants \
  @react-native-async-storage/async-storage @expo/vector-icons \
  react-dom react-native-web @expo/metro-runtime

# NativeWind v4 + Tailwind CSS.
npm install nativewind@^4.2.0 tailwindcss@^3.4.17 --legacy-peer-deps
npm install -D @expo/ngrok@^4.1.0 --legacy-peer-deps

# Align any packages with the installed Expo SDK.
npx expo install --fix

echo
printf 'Setup complete. Start browser preview with: npm run web\n'
printf 'Start Expo Go tunnel with: npm start\n'
printf 'For Codespaces, forward port 8081 and open its HTTPS URL on your iPhone.\n'
