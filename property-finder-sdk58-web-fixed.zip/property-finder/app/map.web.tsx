import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Linking, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { PropertyCard } from "../components/PropertyCard";
import { aiSearch, Filters } from "../lib/ai";
import { BASE, priceOf, properties } from "../lib/data";
import { geocode } from "../lib/geo";

const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

/** Browser fallback: native react-native-maps is intentionally kept in map.tsx for iOS/Android. */
export default function MapScreenWeb() {
  const a = useLocalSearchParams<{ type?: string; q?: string; min?: string; beds?: string; ai?: string }>();
  const [f, setF] = useState<Filters>({ type: a.type, minPrice: Number(a.min) || undefined, beds: Number(a.beds) || undefined });
  const [center, setCenter] = useState({ ...BASE, name: "Gumpang, Surakarta" });
  const [text, setText] = useState(a.ai ?? "");
  const [busy, setBusy] = useState(false);

  const locate = async (q: string) => {
    const g = await geocode(q);
    if (g) setCenter({ lat: g.lat, lng: g.lng, name: g.name });
    else setCenter((v) => ({ ...v, name: q }));
  };

  const run = async (query: string) => {
    if (!query.trim()) return;
    setBusy(true);
    try {
      const nf = await aiSearch(query);
      setF((old) => ({ ...old, ...nf }));
      if (nf.location) await locate(nf.location);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (a.q) void locate(a.q);
    if (a.ai) void run(a.ai);
    // Initial URL parameters are intentionally read once on mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const list = useMemo(() => properties.filter((p) =>
    (!f.maxPrice || priceOf(p) <= f.maxPrice) &&
    (!f.minPrice || priceOf(p) >= f.minPrice) &&
    (!f.beds || p.beds >= f.beds)
  ), [f]);
  const chips = [f.type, f.beds ? `${f.beds}+ beds` : "", f.minPrice ? `from ${usd(f.minPrice)}` : "", f.maxPrice ? `up to ${usd(f.maxPrice)}` : "", center.name].filter(Boolean);
  const openMap = () => Linking.openURL(`https://www.openstreetmap.org/?mlat=${center.lat}&mlon=${center.lng}#map=14/${center.lat}/${center.lng}`);

  return (
    <View className="flex-1 bg-gray-50">
      <SafeAreaView edges={["top"]} className="flex-1">
        <View className="px-4 pt-2 pb-3 gap-3">
          <View className="flex-row items-center bg-white rounded-full px-4 py-3 shadow-sm">
            <Pressable onPress={() => router.back()} hitSlop={10} accessibilityLabel="Go back"><Ionicons name="arrow-back" size={20} color="#0B0B0C" /></Pressable>
            <TextInput className="flex-1 mx-3 text-sm text-ink" placeholder="Search location or describe a property" placeholderTextColor="#9CA3AF" value={text} onChangeText={setText} onSubmitEditing={() => void run(text)} returnKeyType="search" />
            {busy ? <ActivityIndicator size="small" /> : <Pressable onPress={() => void run(text)} accessibilityLabel="Run smart search"><Ionicons name="sparkles" size={19} color="#2E7D32" /></Pressable>}
          </View>
          <View className="flex-row flex-wrap gap-2">
            {chips.map((chip) => <View key={chip} className="bg-white rounded-full px-3 py-2"><Text className="text-xs text-gray-700">{chip}</Text></View>)}
          </View>
        </View>

        <ScrollView contentContainerClassName="px-4 pb-8">
          <Pressable onPress={openMap} className="rounded-3xl overflow-hidden bg-[#E7EBDD] p-5 min-h-52 justify-between" accessibilityRole="link">
            <View className="flex-row items-center justify-between">
              <View className="bg-white/90 rounded-full px-3 py-2 flex-row items-center gap-2"><Ionicons name="location" color="#2E7D32" size={15} /><Text className="text-xs font-semibold text-ink">{center.name}</Text></View>
              <View className="bg-ink rounded-full p-2"><Ionicons name="open-outline" color="#D4F46A" size={17} /></View>
            </View>
            <View className="items-center">
              <View className="flex-row items-center gap-3">
                {list.slice(0, 5).map((p, i) => <View key={p.id} className={`w-9 h-9 rounded-full border-2 border-white items-center justify-center ${i % 2 ? "bg-brand" : "bg-ink"}`}><Ionicons name="home" size={15} color={i % 2 ? "#0B0B0C" : "#D4F46A"} /></View>)}
              </View>
              <Text className="text-xs text-gray-700 mt-3">{list.length} properties around this search</Text>
            </View>
            <Text className="text-xs font-semibold text-ink">Open interactive map ↗</Text>
          </Pressable>

          <View className="flex-row items-center justify-between mt-5 mb-3">
            <Text className="text-lg font-bold text-ink">Matching properties</Text>
            <Text className="text-xs text-gray-500">{list.length} found</Text>
          </View>
          {list.length ? <View className="gap-3">{list.map((p) => <PropertyCard key={p.id} p={{ ...p, location: center.name }} />)}</View> : (
            <View className="bg-white rounded-3xl p-5"><Text className="font-semibold text-ink">No matches found</Text><Text className="text-gray-500 text-sm mt-1">Try a higher budget or fewer bedrooms.</Text></View>
          )}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}
