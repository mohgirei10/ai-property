import { useRef, useState } from "react";
import { FlatList, Image, Pressable, StyleSheet, Text, useWindowDimensions, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useApp } from "../lib/store";

const u = (id: string) => `https://images.unsplash.com/${id}?w=1200&q=80`;
const slides = [
  { img: u("photo-1613490493576-7fde63acd811"), title: "Find your place, faster", body: "Browse houses, apartments and land on one map." },
  { img: u("photo-1600585154340-be6161a56a0c"), title: "Ask, don’t filter", body: "Type “3 bed house under $90k near Kartasura” and we handle the rest." },
  { img: u("photo-1512917774080-9991f1c4c750"), title: "Save what you love", body: "Keep a shortlist and message owners directly." },
];

export default function Onboarding() {
  const { width } = useWindowDimensions();
  const { finishOnboarding } = useApp();
  const [i, setI] = useState(0);
  const ref = useRef<FlatList>(null);
  const last = i === slides.length - 1;

  return (
    <View className="flex-1 bg-ink">
      <FlatList
        ref={ref}
        data={slides}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(s) => s.title}
        onMomentumScrollEnd={(e) => setI(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item }) => (
          <View style={{ width }} className="flex-1 justify-end">
            <Image source={{ uri: item.img }} style={StyleSheet.absoluteFill} resizeMode="cover" />
            <LinearGradient colors={["transparent", "#0B0B0C"]} locations={[0.3, 0.8]} style={StyleSheet.absoluteFill} />
            <View className="px-7 pb-60">
              <Text className="text-white text-4xl font-bold">{item.title}</Text>
              <Text className="text-white/70 text-base mt-3">{item.body}</Text>
            </View>
          </View>
        )}
      />
      <View className="absolute bottom-0 inset-x-0 px-6 pb-12 gap-5">
        <View className="flex-row gap-2">
          {slides.map((s, n) => <View key={s.title} className={`h-1.5 rounded-full ${n === i ? "w-8 bg-brand" : "w-1.5 bg-white/30"}`} />)}
        </View>
        <Pressable onPress={() => (last ? finishOnboarding() : ref.current?.scrollToIndex({ index: i + 1 }))} className="bg-brand rounded-full py-4 items-center">
          <Text className="font-semibold text-ink">{last ? "Get started" : "Continue"}</Text>
        </Pressable>
        <Pressable onPress={finishOnboarding}><Text className="text-white/60 text-center text-sm">Skip</Text></Pressable>
      </View>
    </View>
  );
}
