import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";
import MapView, { Marker } from "react-native-maps";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { PropertyCard } from "../components/PropertyCard";
import { aiSearch, Filters } from "../lib/ai";
import { BASE, priceOf, properties } from "../lib/data";
import { geocode } from "../lib/geo";

const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

export default function MapScreen() {
  const a = useLocalSearchParams<{ type?: string; q?: string; min?: string; beds?: string; ai?: string }>();
  const [f, setF] = useState<Filters>({ type: a.type, minPrice: Number(a.min) || undefined, beds: Number(a.beds) || undefined });
  const [center, setCenter] = useState({ ...BASE, name: "Gumpang, Surakarta" });
  const [text, setText] = useState(a.ai ?? "");
  const [busy, setBusy] = useState(false);
  const [i, setI] = useState(0);
  const map = useRef<MapView>(null);

  const fly = (lat: number, lng: number) => map.current?.animateToRegion({ latitude: lat, longitude: lng, latitudeDelta: 0.02, longitudeDelta: 0.02 }, 500);

  const locate = async (q: string) => {
    const g = await geocode(q);
    if (!g) return;
    setCenter({ lat: g.lat, lng: g.lng, name: g.name });
    setI(0);
    setTimeout(() => fly(g.lat, g.lng), 50);
  };

  const run = async (t: string) => {
    if (!t.trim()) return;
    setBusy(true);
    const nf = await aiSearch(t);
    setF((o) => ({ ...o, ...nf }));
    if (nf.location) await locate(nf.location);
    setI(0);
    setBusy(false);
  };

  useEffect(() => { if (a.q) locate(a.q); if (a.ai) run(a.ai); }, []);

  // Demo listings are re-centred on the searched place. Replace with your real listings API.
  const list = useMemo(
    () =>
      properties
        .map((p) => ({ ...p, lat: center.lat + p.lat - BASE.lat, lng: center.lng + p.lng - BASE.lng, location: center.name }))
        .filter((p) => (!f.maxPrice || priceOf(p) <= f.maxPrice) && (!f.minPrice || priceOf(p) >= f.minPrice) && (!f.beds || p.beds >= f.beds)),
    [center, f],
  );
  const idx = Math.min(i, Math.max(list.length - 1, 0));
  const p = list[idx];
  const go = (n: number) => { const k = (n + list.length) % list.length; setI(k); fly(list[k].lat, list[k].lng); };

  const chips = [f.type, f.beds ? `${f.beds}+ beds` : "", f.minPrice ? `from ${usd(f.minPrice)}` : "", f.maxPrice ? `up to ${usd(f.maxPrice)}` : "", center.name].filter(Boolean);

  return (
    <View className="flex-1 bg-white">
      <MapView ref={map} style={{ flex: 1 }} initialRegion={{ latitude: BASE.lat, longitude: BASE.lng, latitudeDelta: 0.03, longitudeDelta: 0.03 }}>
        {list.map((x, n) => (
          <Marker key={x.id} coordinate={{ latitude: x.lat, longitude: x.lng }} onPress={() => go(n)}>
            <View className={`w-9 h-9 rounded-full items-center justify-center border-2 border-white ${n === idx ? "bg-ink" : "bg-brand"}`}>
              <Ionicons name="home" size={16} color={n === idx ? "#D4F46A" : "#0B0B0C"} />
            </View>
          </Marker>
        ))}
      </MapView>

      <SafeAreaView edges={["top"]} className="absolute top-0 inset-x-0 px-4 gap-2.5">
        <View className="flex-row items-center bg-white rounded-full pl-3 pr-4 py-2.5 shadow-lg">
          <Pressable onPress={() => router.back()} hitSlop={10}><Ionicons name="arrow-back" size={20} /></Pressable>
          <TextInput className="flex-1 mx-2.5 text-sm" placeholder="Smart search: 2 bed under $80k in Solo" placeholderTextColor="#9CA3AF" value={text} onChangeText={setText} onSubmitEditing={() => run(text)} returnKeyType="search" />
          {busy ? <ActivityIndicator size="small" /> : <Ionicons name="sparkles" size={18} color="#2E7D32" />}
        </View>
        <View className="flex-row flex-wrap gap-2">
          {chips.map((c) => <View key={c} className="bg-white rounded-full px-3.5 py-2 shadow"><Text className="text-xs">{c}</Text></View>)}
        </View>
      </SafeAreaView>

      <View className="absolute bottom-0 inset-x-0 p-3 pb-9">
        {p ? (
          <>
            <View className="flex-row items-center justify-between bg-brand rounded-full px-3 py-2 mb-2">
              <Pressable onPress={() => go(idx - 1)}><Ionicons name="arrow-back" size={16} /></Pressable>
              {list.map((x, n) => (
                <Pressable key={x.id} onPress={() => go(n)} className={`w-7 h-7 rounded-full items-center justify-center ${n === idx ? "bg-pine" : ""}`}>
                  <Text className={`text-xs font-medium ${n === idx ? "text-white" : "text-ink"}`}>{n + 1}</Text>
                </Pressable>
              ))}
              <Pressable onPress={() => go(idx + 1)}><Ionicons name="arrow-forward" size={16} /></Pressable>
            </View>
            <PropertyCard p={p} />
          </>
        ) : (
          <View className="bg-white rounded-3xl p-5 shadow-lg"><Text className="font-semibold">No matches</Text><Text className="text-gray-500 text-sm mt-1">Try a higher budget or fewer bedrooms.</Text></View>
        )}
      </View>
    </View>
  );
}
