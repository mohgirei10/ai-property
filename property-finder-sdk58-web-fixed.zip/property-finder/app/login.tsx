import { useState } from "react";
import { KeyboardAvoidingView, Pressable, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../lib/store";

const input = "bg-white/10 rounded-2xl px-4 py-4 text-white text-sm";

export default function Login() {
  const { signIn } = useApp();
  const [up, setUp] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const ok = /\S+@\S+\.\S+/.test(email) && pw.length >= 6 && (!up || name.trim().length > 0);

  return (
    <KeyboardAvoidingView behavior="padding" className="flex-1 bg-ink">
      <SafeAreaView className="flex-1 px-6 pb-4 justify-end">
        <Text className="text-white text-4xl font-bold">{up ? "Create account" : "Welcome back"}</Text>
        <Text className="text-white/60 mt-2 mb-7">Find your next home with AI-powered search.</Text>
        <View className="gap-3">
          {up && <TextInput className={input} placeholder="Full name" placeholderTextColor="#9CA3AF" value={name} onChangeText={setName} />}
          <TextInput className={input} placeholder="Email" placeholderTextColor="#9CA3AF" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
          <TextInput className={input} placeholder="Password (6+ characters)" placeholderTextColor="#9CA3AF" secureTextEntry value={pw} onChangeText={setPw} />
        </View>
        <Pressable
          disabled={!ok}
          onPress={() => signIn({ name: name.trim() || email.split("@")[0], email })}
          className={`rounded-full py-4 items-center mt-5 ${ok ? "bg-brand" : "bg-brand/40"}`}
        >
          <Text className="font-semibold text-ink">{up ? "Sign up" : "Sign in"}</Text>
        </Pressable>
        <Pressable onPress={() => signIn({ name: "Guest", email: "" })} className="py-4"><Text className="text-white/70 text-center text-sm">Continue as guest</Text></Pressable>
        <Pressable onPress={() => setUp(!up)}>
          <Text className="text-white/50 text-center text-sm">{up ? "Have an account? " : "New here? "}<Text className="text-brand">{up ? "Sign in" : "Create account"}</Text></Text>
        </Pressable>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}
