import { FlatList, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { PropertyCard } from "../../components/PropertyCard";
import { properties } from "../../lib/data";
import { useApp } from "../../lib/store";

export default function Favorites() {
  const { favs } = useApp();
  const items = properties.filter((p) => favs.includes(p.id));
  return (
    <SafeAreaView edges={["top"]} className="flex-1 bg-gray-50">
      <Text className="text-3xl font-bold px-5 pt-4">Saved</Text>
      <Text className="text-gray-500 px-5 mt-1 mb-3">{items.length} {items.length === 1 ? "property" : "properties"}</Text>
      <FlatList
        data={items}
        keyExtractor={(p) => p.id}
        contentContainerClassName="px-4 pb-36 gap-3"
        renderItem={({ item }) => <PropertyCard p={item} />}
        ListEmptyComponent={
          <View className="items-center mt-24 px-10">
            <Ionicons name="heart-outline" size={44} color="#9CA3AF" />
            <Text className="font-semibold mt-3">Nothing saved yet</Text>
            <Text className="text-gray-500 text-center mt-1">Tap the heart on any property to keep it here.</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}
