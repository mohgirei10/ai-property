import { useState } from "react";
import { Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { properties } from "../../lib/data";
import { useApp } from "../../lib/store";

const tabs = ["House", "Apartment", "Land"];
const field = "border border-gray-200 rounded-xl px-4 py-3.5 text-sm text-ink";

export default function Discover() {
  const { user } = useApp();
  const [tab, setTab] = useState("House");
  const [ai, setAi] = useState("");
  const [loc, setLoc] = useState("");
  const [min, setMin] = useState("");
  const [beds, setBeds] = useState(0);
  const go = () => router.push({ pathname: "/map", params: { type: tab, q: loc, min, beds: String(beds), ai } });

  return (
    <View className="flex-1 bg-ink">
      <View className="flex-1 justify-end p-6">
        <Image source={{ uri: properties[2].image }} style={StyleSheet.absoluteFill} resizeMode="cover" />
        <LinearGradient colors={["rgba(0,0,0,0.3)", "rgba(0,0,0,0.8)"]} style={StyleSheet.absoluteFill} />
        <SafeAreaView edges={["top"]} className="absolute top-0 left-6">
          <Text className="text-white/80 text-sm mt-2">Hello, {user?.name.split(" ")[0]}</Text>
        </SafeAreaView>
        <Text className="text-white text-4xl font-bold">{"Effortless\nProperty\nDiscovery"}</Text>
      </View>

      <View className="bg-brand rounded-t-[28px] px-3 pt-3 pb-32">
        <View className="flex-row mb-3">
          {tabs.map((t) => (
            <Pressable key={t} onPress={() => setTab(t)} className={`flex-1 items-center py-2.5 rounded-full ${tab === t ? "bg-ink" : ""}`}>
              <Text className={`text-sm font-medium ${tab === t ? "text-white" : "text-ink"}`}>{t}</Text>
            </Pressable>
          ))}
        </View>
        <View className="bg-white rounded-3xl p-4 gap-3">
          <View className={`${field} flex-row items-center bg-gray-50`}>
            <Ionicons name="sparkles" size={16} color="#2E7D32" />
            <TextInput className="flex-1 ml-2 text-sm" placeholder="Ask AI: 3 bed house under $90k near Kartasura" placeholderTextColor="#9CA3AF" value={ai} onChangeText={setAi} onSubmitEditing={go} returnKeyType="search" />
          </View>
          <TextInput className={field} placeholder="Location" placeholderTextColor="#9CA3AF" value={loc} onChangeText={setLoc} />
          <TextInput className={field} placeholder="Min $50,000" placeholderTextColor="#9CA3AF" keyboardType="numeric" value={min} onChangeText={setMin} />
          <Pressable onPress={() => setBeds((beds + 1) % 5)} className={`${field} flex-row items-center justify-between`}>
            <Text className={`text-sm ${beds ? "text-ink" : "text-gray-400"}`}>{beds ? `${beds}+ bedrooms` : "Add Filter"}</Text>
            <Ionicons name="options-outline" size={18} color="#6B7280" />
          </Pressable>
          <Pressable onPress={go} className="bg-ink rounded-full py-4 items-center mt-1"><Text className="text-white font-semibold">Discover</Text></Pressable>
        </View>
      </View>
    </View>
  );
}
