import { Pressable, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../../lib/store";

export default function Profile() {
  const { user, favs, signOut } = useApp();
  return (
    <SafeAreaView edges={["top"]} className="flex-1 bg-gray-50 px-5">
      <Text className="text-3xl font-bold pt-4">Profile</Text>
      <View className="bg-white rounded-3xl p-5 mt-5 flex-row items-center">
        <View className="w-14 h-14 rounded-full bg-ink items-center justify-center">
          <Text className="text-brand text-xl font-bold">{user?.name[0]?.toUpperCase()}</Text>
        </View>
        <View className="ml-4">
          <Text className="font-semibold text-base">{user?.name}</Text>
          <Text className="text-gray-500 text-xs">{user?.email || "Guest"}</Text>
        </View>
      </View>
      <Text className="text-gray-500 mt-4">{favs.length} saved {favs.length === 1 ? "property" : "properties"}</Text>
      <Pressable onPress={signOut} className="bg-ink rounded-full py-4 items-center mt-6"><Text className="text-white font-semibold">Sign out</Text></Pressable>
    </SafeAreaView>
  );
}
