import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";

const icon = (n: string) => ({ color, focused }: { color: string; focused: boolean }) => (
  <Ionicons name={(focused ? n : `${n}-outline`) as any} size={22} color={color} />
);

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarActiveTintColor: "#D4F46A",
        tabBarInactiveTintColor: "#9CA3AF",
        tabBarStyle: { position: "absolute", left: 28, right: 28, bottom: 28, height: 64, borderRadius: 32, backgroundColor: "#0B0B0C", borderTopWidth: 0, paddingBottom: 0 },
        tabBarItemStyle: { height: 64 },
      }}
    >
      <Tabs.Screen name="index" options={{ tabBarIcon: icon("home") }} />
      <Tabs.Screen name="favorites" options={{ tabBarIcon: icon("heart") }} />
      <Tabs.Screen name="profile" options={{ tabBarIcon: icon("person") }} />
    </Tabs>
  );
}
