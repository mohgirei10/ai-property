import "../global.css";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { AppProvider, useApp } from "../lib/store";


function Routes() {
  const { ready, seen, user } = useApp();
  if (!ready) return null;
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Protected guard={!seen}><Stack.Screen name="onboarding" /></Stack.Protected>
      <Stack.Protected guard={seen && !user}><Stack.Screen name="login" /></Stack.Protected>
      <Stack.Protected guard={!!user}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="map" />
        <Stack.Screen name="property/[id]" />
      </Stack.Protected>
    </Stack>
  );
}

export default function Layout() {
  return (
    <AppProvider>
      <StatusBar style="auto" />
      <Routes />
    </AppProvider>
  );
}
