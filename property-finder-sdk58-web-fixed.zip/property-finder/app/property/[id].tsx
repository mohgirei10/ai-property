import { Image, Linking, Pressable, ScrollView, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { Heart } from "../../components/PropertyCard";
import { properties } from "../../lib/data";

export default function Details() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const p = properties.find((x) => x.id === id) ?? properties[0];
  const stats = [
    { icon: "bed-outline", label: `${p.beds} Beds` },
    { icon: "water-outline", label: `${p.baths} Bath` },
    { icon: "expand-outline", label: `${p.area} m²` },
  ] as const;

  return (
    <SafeAreaView className="flex-1 bg-white">
      <View className="flex-row items-center justify-between px-4 py-2">
        <Pressable onPress={() => router.back()}><Ionicons name="arrow-back" size={22} /></Pressable>
        <Text className="font-semibold">Details</Text>
        <Heart id={p.id} />
      </View>

      <ScrollView className="px-4" contentContainerClassName="pb-6">
        <View className="flex-row items-start justify-between mt-2">
          <Text className="flex-1 text-xl font-bold pr-3">{p.title}</Text>
          <View className="bg-brand rounded-full px-3 py-1.5"><Text className="text-pine font-bold">{p.price}</Text></View>
        </View>
        <Text className="text-gray-400 text-xs mt-1">{p.location}</Text>

        <Pressable onPress={() => Linking.openURL(p.url)} className="flex-row items-center border border-gray-200 rounded-full px-4 py-2.5 mt-3">
          <Text className="flex-1 text-blue-600 text-xs" numberOfLines={1}>{p.url}</Text>
          <Ionicons name="open-outline" size={14} color="#2563EB" />
        </Pressable>

        <Image source={{ uri: p.image }} className="w-full h-72 rounded-3xl mt-4" />

        <View className="flex-row justify-around bg-gray-100 rounded-2xl py-3.5 mt-4">
          {stats.map((s) => (
            <View key={s.label} className="flex-row items-center">
              <Ionicons name={s.icon} size={18} color="#374151" />
              <Text className="text-xs ml-1.5 text-gray-700">{s.label}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <View className="px-4 pb-4">
        <Pressable className="bg-ink rounded-full py-4 items-center"><Text className="text-white font-semibold">Chat with Owner</Text></Pressable>
      </View>
    </SafeAreaView>
  );
}
