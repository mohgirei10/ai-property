module.exports = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: { extend: { colors: { brand: "#D4F46A", ink: "#0B0B0C", pine: "#2E7D32" } } },
  plugins: [],
};
